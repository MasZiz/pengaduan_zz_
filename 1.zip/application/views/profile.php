
<div id="layoutSidenav_content">
      <main>
          <div class="container-fluid px-4"><CENTER>
              <h1 class="mt-4">Twdraqojii</h1>

           

                      <table class="table ">

                            <Center>
                            <div class="card" style="width: 18rem;">
                              <img src="<?= base_url('assets/')?>img/32.png" class="card-img-top" alt="stylesheet">
                                </div>
                              </div>
                             

                           <tr>
                              <td>
                                  <h6>Nama</h6>
                              </td>
                              <td>
                                  <h6><?= $this->session->userdata('username'); ?></h6>
                              </td>
                          </tr>
                           <tr>
                              <td>
                                  <h6>level </h6>
                              </td>
                              <td>
                              <h6><?= $this->session->userdata('level'); ?></h6>
                              </td>
                          </tr>


                     